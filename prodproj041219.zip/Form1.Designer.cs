﻿namespace ProductionProject
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.inputFileLabel = new System.Windows.Forms.Label();
            this.routeBox = new System.Windows.Forms.TextBox();
            this.openButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.pictureBoxInput = new System.Windows.Forms.PictureBox();
            this.textToEmbed = new System.Windows.Forms.TextBox();
            this.embedButton = new System.Windows.Forms.Button();
            this.embedLabel = new System.Windows.Forms.Label();
            this.decodeButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxInput)).BeginInit();
            this.SuspendLayout();
            // 
            // inputFileLabel
            // 
            this.inputFileLabel.AutoSize = true;
            this.inputFileLabel.Location = new System.Drawing.Point(13, 59);
            this.inputFileLabel.Name = "inputFileLabel";
            this.inputFileLabel.Size = new System.Drawing.Size(66, 13);
            this.inputFileLabel.TabIndex = 0;
            this.inputFileLabel.Text = "Image route:";
            // 
            // routeBox
            // 
            this.routeBox.Location = new System.Drawing.Point(85, 55);
            this.routeBox.Name = "routeBox";
            this.routeBox.Size = new System.Drawing.Size(215, 20);
            this.routeBox.TabIndex = 1;
            // 
            // openButton
            // 
            this.openButton.Location = new System.Drawing.Point(306, 55);
            this.openButton.Name = "openButton";
            this.openButton.Size = new System.Drawing.Size(81, 20);
            this.openButton.TabIndex = 2;
            this.openButton.Text = "Open...";
            this.openButton.UseVisualStyleBackColor = true;
            this.openButton.Click += new System.EventHandler(this.openButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(393, 55);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(81, 20);
            this.saveButton.TabIndex = 4;
            this.saveButton.Text = "Save...";
            this.saveButton.UseVisualStyleBackColor = true;
            // 
            // pictureBoxInput
            // 
            this.pictureBoxInput.BackColor = System.Drawing.SystemColors.Control;
            this.pictureBoxInput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxInput.Location = new System.Drawing.Point(488, 12);
            this.pictureBoxInput.Name = "pictureBoxInput";
            this.pictureBoxInput.Size = new System.Drawing.Size(300, 300);
            this.pictureBoxInput.TabIndex = 5;
            this.pictureBoxInput.TabStop = false;
            // 
            // textToEmbed
            // 
            this.textToEmbed.Location = new System.Drawing.Point(85, 98);
            this.textToEmbed.Multiline = true;
            this.textToEmbed.Name = "textToEmbed";
            this.textToEmbed.Size = new System.Drawing.Size(215, 103);
            this.textToEmbed.TabIndex = 6;
            // 
            // embedButton
            // 
            this.embedButton.Location = new System.Drawing.Point(306, 181);
            this.embedButton.Name = "embedButton";
            this.embedButton.Size = new System.Drawing.Size(81, 20);
            this.embedButton.TabIndex = 7;
            this.embedButton.Text = "Embed";
            this.embedButton.UseVisualStyleBackColor = true;
            this.embedButton.Click += new System.EventHandler(this.embedButton_Click);
            // 
            // embedLabel
            // 
            this.embedLabel.AutoSize = true;
            this.embedLabel.Location = new System.Drawing.Point(26, 101);
            this.embedLabel.Name = "embedLabel";
            this.embedLabel.Size = new System.Drawing.Size(53, 13);
            this.embedLabel.TabIndex = 8;
            this.embedLabel.Text = "Message:";
            this.embedLabel.Click += new System.EventHandler(this.embedLabel_Click);
            // 
            // decodeButton
            // 
            this.decodeButton.Location = new System.Drawing.Point(393, 181);
            this.decodeButton.Name = "decodeButton";
            this.decodeButton.Size = new System.Drawing.Size(75, 20);
            this.decodeButton.TabIndex = 9;
            this.decodeButton.Text = "Decode";
            this.decodeButton.UseVisualStyleBackColor = true;
            this.decodeButton.Click += new System.EventHandler(this.decodeButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(800, 319);
            this.Controls.Add(this.decodeButton);
            this.Controls.Add(this.embedLabel);
            this.Controls.Add(this.embedButton);
            this.Controls.Add(this.textToEmbed);
            this.Controls.Add(this.pictureBoxInput);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.openButton);
            this.Controls.Add(this.routeBox);
            this.Controls.Add(this.inputFileLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxInput)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label inputFileLabel;
        private System.Windows.Forms.TextBox routeBox;
        private System.Windows.Forms.Button openButton;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.PictureBox pictureBoxInput;
        private System.Windows.Forms.TextBox textToEmbed;
        private System.Windows.Forms.Button embedButton;
        private System.Windows.Forms.Label embedLabel;
        private System.Windows.Forms.Button decodeButton;
    }
}

