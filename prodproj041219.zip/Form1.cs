﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProductionProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void openButton_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog open = new OpenFileDialog();
                open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp";
                open.InitialDirectory = @"C:\Users\User\Desktop\UNI\1920\productionProject\outputFiles";
                if (open.ShowDialog() == DialogResult.OK)

                {
                    routeBox.Text = open.FileName.ToString();
                    pictureBoxInput.ImageLocation = open.FileName;
                } // end of if opendialog


            } // end of try

            catch (Exception)
            {
                throw new ApplicationException("Failed loading image");
            }
        }

        private void embedButton_Click(object sender, EventArgs e)
        {
            Bitmap bmp = new Bitmap(routeBox.Text);

            for (int i = 0; i < bmp.Width; i++)
            {
                for (int j = 0; j < bmp.Height; j++)
                {
                    Color pixelCol = bmp.GetPixel(i, j);

                    if (i < 1 && j < textToEmbed.TextLength)
                    {
                        Console.WriteLine("--------------------");
                        Console.WriteLine("pixel " + i + "|" + j);
                        

                        char letter = Convert.ToChar(textToEmbed.Text.Substring(j, 1));
                        int value = Convert.ToInt32(letter);
                        Console.WriteLine("letter : " + letter + " value : " + value);
                        Console.WriteLine(value);

                        bmp.SetPixel(i, j, Color.FromArgb(pixelCol.R, pixelCol.G, value)); 
                        
                        Console.WriteLine("R [" + i + "][" + j + "] = " + pixelCol.R);
                        Console.WriteLine("G [" + i + "][" + j + "] = " + pixelCol.G);
                        Console.WriteLine("B [" + i + "][" + j + "] = " + pixelCol.B);
                    }
                }
            }
            SaveFileDialog saveFile = new SaveFileDialog();
            saveFile.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp";

            if (saveFile.ShowDialog() == DialogResult.OK)
            {
                routeBox.Text = saveFile.FileName.ToString();
                pictureBoxInput.ImageLocation = routeBox.Text;

            }
            bmp.Save(routeBox.Text);
        }

        private void embedLabel_Click(object sender, EventArgs e)
        {

        }

        private void decodeButton_Click(object sender, EventArgs e)
        {
            Bitmap bmp = new Bitmap(routeBox.Text);
            string message = "";
            for (int i = 0; i < bmp.Width; i++)
            {
                for (int j = 0; j < bmp.Height; j++)
                {
                    Color pixelCol = bmp.GetPixel(i, j);

                    if (i < 1 && j < 25)
                    {

                        int value = pixelCol.B;
                        char c = Convert.ToChar(value);
                        string letter = Encoding.ASCII.GetString(new byte[] { Convert.ToByte(c) });
                        Console.WriteLine("value: "+value+". c: "+c+". letter: "+letter);
                        message = message + letter;

                    }
                }
            }
            textToEmbed.Text = message;
        }
    }
}
